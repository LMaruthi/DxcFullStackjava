package com.myusers.task;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.myusers.task.dao.UserDao;
import com.myusers.task.model.Users;

@Controller
public class HomeController {

	@Autowired
	UserDao dao;
	@RequestMapping(value = "/test")
	public String home() {
		System.out.println("Home Method");
		//String s=dao.SaveMethod(new Users(105, "virendersehwag", "blast", "what is the name of your childhood friend", "Ram"));
		return "home";
	}
	
	@RequestMapping(value = "/login")
	public String loginpage() {
		return "login";
		}
	@RequestMapping(value = "/createdsuccessful")
	public String creatsucces() {
		return "createdsuccessful";
		}
	
	@RequestMapping(value = "/createnewaccount")
	public String newuserpage() {
		return "createnewaccount";
	}
	@RequestMapping(value="create")
	public String newuser(Model model,@ModelAttribute Users users)	{
		String status=dao.SaveMethod(users);
		System.out.println(status);
		model.addAttribute("status",status);
		return "createdsuccessful";
	}
	
	
	@RequestMapping(value = "/loginValidation")
	public String loginValidation(Model model,
			@RequestParam("username") String username,
			@RequestParam("password") String password) {
		System.out.println("login method");
		System.out.println(username);
		System.out.println(password);
		ArrayList<Users> users=dao.validateLogin(username);
		model.addAttribute("users", users);
		String pswd=users.get(0).getPassword();
		System.out.println(pswd);
		  if(pswd.equals(password)) {
			  return "loginsuccess"; 
			  } 
		  else { 
			  return "loginInvalid"; 
			  }		 
	}
	
	@RequestMapping(value = "/forgotPassword")
	public String forgotPassword() {
		System.out.println("Forgot password page displayed");
		return "forgotPassword";
	}
	
	//Change Password
		int userId=0;
		
	@RequestMapping(value = "/accountValidate")
	public String accountValidate(Model model,
			@RequestParam("userId") String userId,
			@RequestParam("securityQuestion") String securityQuestion,
			@RequestParam("securityAnswer") String securityAnswer) {
		System.out.println(userId);
		System.out.println(securityQuestion);
		System.out.println(securityAnswer);
		
		int uId=Integer.parseInt(userId);
		this.userId=uId;
		
		Users users=dao.getdetails(uId);
		String sq=users.getSecurityQuestion();
		System.out.println(sq);
		String sa=users.getSecurityAnswer();
		System.out.println(sa);
		if(sq.equals(securityQuestion)) {
			if(sa.equals(securityAnswer))
				return "changePassword";
		}
		return "forgotPasswordInvalid";
	}	
	
	@RequestMapping(value = "/changePassword")
	public String changePassword(Model model, 
			@RequestParam("password") String password) {
			String s=dao.updatePassword(userId, password);
			System.out.println(s);
			return "changePasswordSuccess";
	}	
}
