package com.myusers.task.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.myusers.task.model.Users;

@Component
@Transactional
public class UserDao {
	
	@Autowired
	SessionFactory factory;
	
	public String SaveMethod(Users users) {
		
		try {
			Session session= factory.getCurrentSession();
			session.save(users);
			return"created";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return"cannot create";
	}
	
	public ArrayList<Users> validateLogin(String username){
		
		try {
			
			Session session =factory.getCurrentSession();
			Criteria ct=session.createCriteria(Users.class);
			ct.add(Restrictions.like("username", username));
			ArrayList<Users> user=(ArrayList<Users>)ct.list();
			return user;		
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Users getdetails(int userId) {
	try {
		Session session=factory.getCurrentSession();
		Users users = session.get(Users.class, userId);
		return users;
	}
	catch (Exception e) {
		e.printStackTrace();
	}	
	return null;
	}
	
	public String updatePassword(int userId, String password) {
		
		try {
			Session session=factory.getCurrentSession();
			Query query=session.createQuery("update Users set password=:password where userId=:userId");
			query.setParameter("userId", userId);
			query.setParameter("password", password);
			int res=query.executeUpdate();
			if(res>0)
			{
				return "Updated";
			}
			}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	return "can not update";}
	
}
