function isPasswordMatch() {
var pwd= document.getElementById('pass1').value;
var pwd1=document.getElementById('pass2').value;
if(pwd != pwd1)
{
alert('invalid password');
return false;
}
else
{
alert('valid password');
return true;
}
}
   types=['select','Graduates','Post Graduates']; 
function filldd()
{
    
var typeDD=document.getElementById('type');
for(i=0;i<types.length;i++){
var ele=document.createElement('option');
ele.text=types[i];
typeDD.add(ele,i+1)
}
}


   data=[['computer science','electronics and communication', 'information technology','bachelor of arts'],['masters of arts','masters in computers']];


function fillData()
{
var typeDDN=document.getElementById('type');
  var selectedIdx= typeDDN.selectedIndex;

console.log(selectedIdx);

var dataDD=document.getElementById('dd');

dataDD.innerText=null;


for(i=0;i<data[selectedIdx-1].length;i++)
{

var ele=document.createElement('option');
ele.text=data[selectedIdx-1][i];

dataDD.add(ele,i+1)


}


}
function alpbet(e)
{

if(!( e.which >= 65 && e.which <=122 ))
{
e.preventDefault();
}
}
function uname() {
  var a = document.forms["myf"]["myt"].value;
  if (a == "") {
    alert("user name  must be filled");
    return false;
  }
}
function paas() {
  var b = document.forms["myFo"]["pass1"].value;
  if (b == "") {
    alert("password  must be filled");
    return false;
  }
}
function cpaas() {
  var c = document.forms["myFor"]["pass2"].value;
  if (c == "") {
    alert("confirm password  must be filled");
    return false;
  }
}
function db() {
  var d = document.forms["myForm"]["dbm"].value;
  if (d == "") {
    alert("date of birth  must be filled");
    return false;
  }
}